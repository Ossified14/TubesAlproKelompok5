package ui;

public class MenuData {
  private String[] menu = {
    "Tambah jenis layanan",
    "Ubah jumlah lembar",
    "Tampilkan pesanan",
    "Hapus layanan",
    "Hitung total biaya"
  };

  public String[] getMenu() {
    return menu;
  }
} 