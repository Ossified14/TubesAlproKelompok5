import ui.MenuView;

public class App {
    public static void main(String[] args) {
        MenuView menuView = new MenuView();

        menuView.tampilkanMenu();
    }
}