package metode;

public class HitungTotalBiaya {
  //Ambil data dari pesanan
  //dan hitung harganya sesuai dengan bobot
  //untuk harga layanan dan jumlah lembarnya
}
