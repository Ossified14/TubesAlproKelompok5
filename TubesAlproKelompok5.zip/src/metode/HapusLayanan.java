package metode;

public class HapusLayanan {
  //ambil data dri Pesanan.java dan hapus isi dari dataPesanan
}