package metode;

public class UbahJumlahLembar {
  //ambil data dari Pesanan.java dan ubah jumlah lembarnya
}
