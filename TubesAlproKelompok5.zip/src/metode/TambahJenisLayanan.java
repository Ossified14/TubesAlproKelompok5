package metode;

public class TambahJenisLayanan {
  //ambil data dari JenisPesanan.java dan masukkan ke data Pesanan.java
}