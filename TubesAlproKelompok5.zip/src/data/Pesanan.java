package data;

public class Pesanan {
  private String[] dataPesanan = {
    //di input dari menu mau
    //di sin udah ada nilai default buat lembar
  };

  public String[] getDataPesanan() {
    return dataPesanan;
  }
} 