package data;

public class JenisPesanan {
  private String[] dataJenisPesanan = {
    "Print",
    "Fotocopy"
  };

  public String[] getDataPesanan() {
    return dataJenisPesanan;
  }
}
